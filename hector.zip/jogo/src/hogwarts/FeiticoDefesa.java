package hogwarts;

public class FeiticoDefesa {


	private int protecao;
	
	
	
	public int getProtecao() {
		return protecao;
	}



	public void setProtecao(int protecao) {
		this.protecao = protecao;
	}



	public void lancarPoder() {
		
	}

}
