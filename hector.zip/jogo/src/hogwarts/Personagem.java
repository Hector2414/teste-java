package hogwarts;

public abstract class Personagem {

	private Casa casa = new Casa();
	private int vida;
	private String nome;
	
	
	
	public Casa getCasa() {
		return casa;
	}
	public void setCasa(Casa casa) {
		this.casa = casa;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	public void lancarFeitico(Feitico Personagem) {
		
	}

}
