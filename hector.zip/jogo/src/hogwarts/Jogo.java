package hogwarts;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Jogo {
	private Scanner scanner;
	private List<Bruxo> bruxos;
	private List<Casa> casas;
	private List<CriaturaMagica> criaturas;
	private List<Feitico> feiticos;
	
	public Jogo() {
		scanner = new Scanner(System.in);	
		bruxos = new ArrayList<>();
		casas = new ArrayList<>();
		criaturas = new ArrayList<>();
		feiticos = new ArrayList<>();
		iniciarCasas();
	}
	
	public void iniciar() {
		
		while(true) {
			MostrarMenu();
			int opcao = scanner.nextInt();
			scanner.nextLine();
			
			switch(opcao) {
			case 1:
				criarBruxo();
				break;
			case 2:
				aprenderFeitico();
				break;
			case 3:
				lancarFeitico();
				break;
			case 4:
				verInventario();
				break;
			case 5:
				completarMissao();
				break;
			case 6:
				listarBruxos();
				break;
			case 7:
				ListarCasas();
				break;
			case 8:
				listarFeiticos();
				break;
			case 9:
				criaCriaturaMagica();
				break;
			case 10:
				listarCriaturaMagica();
				break;
			case 11:
				System.out.println("Saindo do jogo.....");
				scanner.close();
				return;
			default:
				System.out.println("Opção inválida! Tente novamente");
			}
		}
	}

	
	private void MostrarMenu() {
		System.out.println("=========Menu do Jogo=========");
		System.out.println("1. Criar Bruxo");
		System.out.println("2. Aprender Feitiço");
		System.out.println("3. Lançar Feitiço");
		System.out.println("4. Ver Inventário");
		System.out.println("5. Completar Missão");
		System.out.println("6. Listar Bruxos");
		System.out.println("7. Listar Casas");
		System.out.println("8. Listar Feitiços");
		System.out.println("9. Criar criaturas mágicas");
		System.out.println("10 Listar criatura mágicas");
		System.out.println("11. Sair");
		System.out.println("Escolha uma opção: ");
	}
	
	private void iniciarCasas() {

	}
	

	public void criarBruxo(){
	
	}

	private void aprenderFeitico(){
	
	}

	private void lancarFeitico() {
  	 

	}

	private void verInventario() {
	
		
	}

	private void completarMissao(){}

	private void listarBruxos(){
		
	}

	private void ListarCasas(){}

	private void listarFeiticos(){
		
	}
	

	private void criaCriaturaMagica(){
		
		
				
	}

	private void listarCriaturaMagica(){
				
	}
	
}
