package hogwarts;

public class CriaturaMagica  {

private String especie;





public String getEspecie() {
	return especie;
}


public void setEspecie(String especie) {
	this.especie = especie;
}





public void lancarFeitico(Feitico Personagem) {
	
}
}
