package hogwarts;

public class Bruxo{
	
	Varinha varinha = new Varinha();
	Inventario inventario = new Inventario();
	
	
	
	
	
	public Varinha getVarinha() {
		return varinha;
	}

	public void setVarinha(Varinha varinha) {
		this.varinha = varinha;
	}

	public Inventario getInventario() {
		return inventario;
	}

	public void setInventario(Inventario inventario) {
		this.inventario = inventario;
	}

	
	public void lancarFeitico(Feitico Personagem) {
		
	}
	
	public void aprenderFeitico() {
		
	}

}
