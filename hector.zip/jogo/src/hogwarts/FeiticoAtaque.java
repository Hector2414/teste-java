package hogwarts;

public class FeiticoAtaque  {


	private int dano;

	public int getDano() {
		return dano;
	}

	public void setDano(int dano) {
		this.dano = dano;
	}
	
	
	
public void lancarPoder() {
		
	}
}
