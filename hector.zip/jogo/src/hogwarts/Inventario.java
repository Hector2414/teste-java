package hogwarts;

import java.util.ArrayList;
import java.util.List;

public class Inventario {

	
	private List<Item>itens = new ArrayList<Item>();

	
	
	
	public List<Item> getItens() {
		return itens;
	}

	public void setItens(List<Item> itens) {
		this.itens = itens;
	}

	
	
	public void adicionarItem() {
		
	}
	
	public void removerItens() {}
	
}
