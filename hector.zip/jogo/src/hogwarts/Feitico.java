package hogwarts;

public abstract class Feitico extends FeiticoDefesa  {

	private String nome;
	private int poder;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getPoder() {
		return poder;
	}
	public void setPoder(int poder) {
		this.poder = poder;
	}
	
	
	public void lancarPoder() {
		
	}

}

